//
// Created by Administrator on 2023-05-04.
//

#ifndef LAB10B_FUNCTIONS_H
#define LAB10B_FUNCTIONS_H
struct Elek{
    int from, to, length;
};
int cmp(const void *a, const void *b);
bool igeretes(int x[], int n);
#endif //LAB10B_FUNCTIONS_H
